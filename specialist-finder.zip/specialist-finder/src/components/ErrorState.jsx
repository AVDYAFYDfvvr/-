export default function ErrorState({ message, onRetry }) {
  return (
    <div className="state-card state-error" role="alert">
      <div className="state-icon">!</div>
      <h3>Не удалось загрузить данные</h3>
      <p>{message}</p>
      {onRetry && <button className="button button-primary" onClick={onRetry}>Повторить</button>}
    </div>
  );
}
