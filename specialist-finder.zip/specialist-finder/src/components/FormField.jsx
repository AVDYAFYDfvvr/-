export default function FormField({ label, name, error, hint, children, required = true }) {
  return (
    <div className="form-field">
      <label htmlFor={name}>{label}{required ? ' *' : ''}</label>
      {children}
      {hint && !error && <small className="field-hint">{hint}</small>}
      {error && <small className="field-error">{error}</small>}
    </div>
  );
}
