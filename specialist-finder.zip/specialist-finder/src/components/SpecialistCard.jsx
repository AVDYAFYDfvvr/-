import { Link } from 'react-router-dom';
import Avatar from './Avatar';

const statusLabels = { available: 'Свободен для заказа', busy: 'Занят' };

export default function SpecialistCard({ specialist, actions }) {
  const skills = specialist.skills.split(',').map((skill) => skill.trim()).filter(Boolean).slice(0, 4);

  return (
    <article className="specialist-card">
      <div className="card-top">
        <Avatar src={specialist.image} alt={specialist.fullName} size="large" />
        <div className="card-headline">
          <span className={`status status-${specialist.status}`}>
            <span className="status-dot" />
            {statusLabels[specialist.status] || 'Статус не указан'}
          </span>
          <h3>{specialist.fullName}</h3>
          <p className="muted">{specialist.profession}</p>
        </div>
      </div>

      <div className="skill-list">
        {skills.map((skill) => <span className="skill" key={skill}>{skill}</span>)}
      </div>

      <div className="card-meta">
        <span>⌁ {specialist.city}</span>
        <span>{specialist.experienceYears} лет опыта</span>
        <strong>{new Intl.NumberFormat('ru-RU').format(specialist.hourlyRate)} ₸/ч</strong>
      </div>

      <p className="card-description">{specialist.description}</p>

      <div className="card-actions">
        <Link to={`/items/${specialist.id}`} className="button button-secondary">Профиль</Link>
        {actions}
      </div>
    </article>
  );
}
