export default function LoadingState({ label = 'Загрузка…' }) {
  return (
    <div className="state-card" role="status">
      <div className="spinner" />
      <p>{label}</p>
    </div>
  );
}
