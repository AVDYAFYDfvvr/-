export default function Avatar({ src, alt, size = 'medium' }) {
  const fallback = `https://ui-avatars.com/api/?name=${encodeURIComponent(alt || 'User')}&background=111827&color=ffffff`;
  return (
    <img
      className={`avatar avatar-${size}`}
      src={src || fallback}
      alt={alt}
      loading="lazy"
      onError={(event) => { event.currentTarget.src = fallback; }}
    />
  );
}
