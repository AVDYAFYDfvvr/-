const DUMMY_USERS_URL = 'https://dummyjson.com/users?limit=30';

export async function fetchDummyUsers(signal) {
  const response = await fetch(DUMMY_USERS_URL, { signal });
  if (!response.ok) throw new Error(`DummyJSON вернул HTTP ${response.status}.`);
  return response.json();
}
