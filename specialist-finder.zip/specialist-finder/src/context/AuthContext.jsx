import { createContext, useContext, useEffect, useMemo, useState } from 'react';
import { apiRequest } from '../services/api';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let active = true;
    apiRequest('/auth/me')
      .then((data) => {
        if (active) setUser(data.user);
      })
      .catch(() => {
        if (active) setUser(null);
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => { active = false; };
  }, []);

  async function login(credentials) {
    const data = await apiRequest('/auth/login', { method: 'POST', body: credentials });
    setUser(data.user);
    return data.user;
  }

  async function register(payload) {
    const data = await apiRequest('/auth/register', { method: 'POST', body: payload });
    setUser(data.user);
    return data.user;
  }

  async function logout() {
    await apiRequest('/auth/logout', { method: 'POST' }).catch(() => {});
    setUser(null);
  }

  const value = useMemo(() => ({ user, loading, login, register, logout }), [user, loading]);
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  return useContext(AuthContext);
}
