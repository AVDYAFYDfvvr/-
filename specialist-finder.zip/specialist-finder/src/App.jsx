import { NavLink, Navigate, Outlet, Route, Routes } from 'react-router-dom';
import { useAuth } from './context/AuthContext';
import { useTheme } from './context/ThemeContext';
import ProtectedRoute from './components/ProtectedRoute';
import HomePage from './pages/HomePage';
import SpecialistsPage from './pages/SpecialistsPage';
import SpecialistDetailsPage from './pages/SpecialistDetailsPage';
import RegisterPage from './pages/RegisterPage';
import LoginPage from './pages/LoginPage';
import DashboardPage from './pages/DashboardPage';
import SpecialistFormPage from './pages/SpecialistFormPage';
import ExplorePage from './pages/ExplorePage';
import NotFoundPage from './pages/NotFoundPage';

function Header() {
  const { user, logout } = useAuth();
  const { theme, toggleTheme } = useTheme();

  return (
    <header className="site-header">
      <div className="container nav-wrap">
        <NavLink to="/" className="brand">
          <span className="brand-mark">P</span>
          <span>ProFinder</span>
        </NavLink>

        <nav className="main-nav" aria-label="Основная навигация">
          <NavLink to="/" end>Главная</NavLink>
          <NavLink to="/specialists">Специалисты</NavLink>
          <NavLink to="/explore">API Explore</NavLink>
          {user && <NavLink to="/dashboard">Кабинет</NavLink>}
        </nav>

        <div className="auth-actions">
          <button
            className="theme-toggle"
            type="button"
            onClick={toggleTheme}
            aria-label={theme === 'dark' ? 'Включить светлую тему' : 'Включить тёмную тему'}
            title={theme === 'dark' ? 'Светлая тема' : 'Тёмная тема'}
          >
            <span aria-hidden="true">{theme === 'dark' ? '☼' : '☾'}</span>
          </button>
          {user ? (
            <>
              <span className="user-chip">{user.name}</span>
              <button className="button button-ghost" onClick={logout}>Выйти</button>
            </>
          ) : (
            <>
              <NavLink className="button button-ghost" to="/login">Войти</NavLink>
              <NavLink className="button button-primary" to="/register">Регистрация</NavLink>
            </>
          )}
        </div>
      </div>
    </header>
  );
}

function DashboardLayout() {
  return (
    <>
      <div className="private-bar">
        <div className="container private-bar-inner">
          <div>
            <strong>Личный кабинет</strong>
            <span> Управление вашими профилями специалистов</span>
          </div>
          <NavLink className="button button-primary button-small" to="/dashboard/new">+ Новый профиль</NavLink>
        </div>
      </div>
      <main className="page-shell"><Outlet /></main>
    </>
  );
}

export default function App() {
  return (
    <div className="app-shell">
      <Header />
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/specialists" element={<SpecialistsPage />} />
        <Route path="/items/:id" element={<SpecialistDetailsPage />} />
        <Route path="/register" element={<RegisterPage />} />
        <Route path="/login" element={<LoginPage />} />
        <Route path="/explore" element={<ExplorePage />} />
        <Route path="/dashboard" element={<ProtectedRoute />}>
          <Route element={<DashboardLayout />}>
            <Route index element={<DashboardPage />} />
            <Route path="new" element={<SpecialistFormPage mode="create" />} />
            <Route path="edit/:id" element={<SpecialistFormPage mode="edit" />} />
          </Route>
        </Route>
        <Route path="/404" element={<NotFoundPage />} />
        <Route path="*" element={<Navigate to="/404" replace />} />
      </Routes>
    </div>
  );
}
