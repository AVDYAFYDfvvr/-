import { useEffect, useMemo, useState } from 'react';
import EmptyState from '../components/EmptyState';
import ErrorState from '../components/ErrorState';
import LoadingState from '../components/LoadingState';
import PageHeader from '../components/PageHeader';
import SpecialistCard from '../components/SpecialistCard';
import { apiRequest } from '../services/api';

export default function SpecialistsPage() {
  const [specialists, setSpecialists] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [query, setQuery] = useState('');
  const [status, setStatus] = useState('all');

  async function load() {
    setLoading(true); setError('');
    try {
      const data = await apiRequest('/specialists');
      setSpecialists(data.specialists);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { load(); }, []);

  const filtered = useMemo(() => {
    const normalized = query.trim().toLowerCase();
    return specialists.filter((item) => {
      const matchesQuery = !normalized || `${item.fullName} ${item.profession} ${item.skills} ${item.city}`.toLowerCase().includes(normalized);
      const matchesStatus = status === 'all' || item.status === status;
      return matchesQuery && matchesStatus;
    });
  }, [specialists, query, status]);

  return (
    <main className="container page-content">
      <PageHeader
        eyebrow="Каталог"
        title="Специалисты"
        text="Публичный список профилей из собственного сохраняемого backend-хранилища."
      />
      <section className="toolbar" aria-label="Фильтры каталога">
        <div className="search-wrap">
          <label htmlFor="specialist-search">Поиск</label>
          <input id="specialist-search" value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Имя, профессия, навык или город" />
        </div>
        <div>
          <label htmlFor="status-filter">Статус</label>
          <select id="status-filter" value={status} onChange={(e) => setStatus(e.target.value)}>
            <option value="all">Все</option>
            <option value="available">Свободен</option>
            <option value="busy">Занят</option>
          </select>
        </div>
      </section>

      {loading && <LoadingState label="Загружаем каталог…" />}
      {error && !loading && <ErrorState message={error} onRetry={load} />}
      {!loading && !error && filtered.length === 0 && <EmptyState title="Ничего не найдено" text="Измените поисковый запрос или фильтр статуса." />}
      {!loading && !error && filtered.length > 0 && (
        <div className="card-grid">
          {filtered.map((specialist) => <SpecialistCard specialist={specialist} key={specialist.id} />)}
        </div>
      )}
    </main>
  );
}
