import { useEffect, useMemo, useState } from 'react';
import Avatar from '../components/Avatar';
import EmptyState from '../components/EmptyState';
import ErrorState from '../components/ErrorState';
import LoadingState from '../components/LoadingState';
import PageHeader from '../components/PageHeader';
import { fetchDummyUsers } from '../services/dummyJson';

export default function ExplorePage() {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [query, setQuery] = useState('');

  async function load(signal) {
    setLoading(true); setError('');
    try {
      const data = await fetchDummyUsers(signal);
      setUsers(Array.isArray(data.users) ? data.users : []);
    } catch (err) {
      if (err.name !== 'AbortError') setError(err.message || 'Ошибка сети.');
    } finally {
      if (!signal?.aborted) setLoading(false);
    }
  }

  useEffect(() => {
    const controller = new AbortController();
    load(controller.signal);
    return () => controller.abort();
  }, []);

  const filtered = useMemo(() => {
    const normalized = query.trim().toLowerCase();
    if (!normalized) return users;
    return users.filter((user) => `${user.firstName} ${user.lastName} ${user.company?.title || ''} ${user.address?.city || ''}`.toLowerCase().includes(normalized));
  }, [users, query]);

  return (
    <main className="container page-content">
      <PageHeader
        eyebrow="Внешний API"
        title="API Explore"
        text="Данные подгружаются через реальный GET fetch() с DummyJSON /users. После загрузки поиск работает по уже сохранённому state без новой сетевой загрузки."
      />

      <div className="api-note">
        <strong>Источник:</strong> https://dummyjson.com/users — в интерфейсе используются только профильные поля: имя, фото, возраст, роль/компания, город, email и телефон. Остальные поля ответа API не отображаются.
      </div>

      <section className="toolbar">
        <div className="search-wrap">
          <label htmlFor="api-search">Поиск по загруженным данным</label>
          <input id="api-search" value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Имя, должность или город" />
        </div>
        <div className="toolbar-meta">Найдено: <strong>{filtered.length}</strong></div>
        {!loading && <button className="button button-secondary" onClick={() => load(new AbortController().signal)}>Обновить GET</button>}
      </section>

      {loading && <LoadingState label="Выполняем GET к DummyJSON…" />}
      {error && !loading && <ErrorState message={error} onRetry={() => load(new AbortController().signal)} />}
      {!loading && !error && filtered.length === 0 && <EmptyState title="По этому запросу ничего нет" text="Попробуйте изменить поиск. Данные API уже загружены в state." />}
      {!loading && !error && filtered.length > 0 && (
        <div className="api-grid">
          {filtered.map((user) => (
            <article className="api-user-card" key={user.id}>
              <div className="card-top">
                <Avatar src={user.image} alt={`${user.firstName} ${user.lastName}`} size="medium" />
                <div>
                  <h3>{user.firstName} {user.lastName}</h3>
                  <p className="muted">{user.company?.title || 'Позиция не указана'}</p>
                </div>
              </div>
              <div className="api-data">
                <div><span>Возраст</span><strong>{user.age}</strong></div>
                <div><span>Город</span><strong>{user.address?.city || '—'}</strong></div>
                <div><span>Компания</span><strong>{user.company?.name || '—'}</strong></div>
                <div><span>Email</span><a href={`mailto:${user.email}`}>{user.email}</a></div>
                <div><span>Телефон</span><a href={`tel:${user.phone}`}>{user.phone}</a></div>
              </div>
            </article>
          ))}
        </div>
      )}

      <div className="api-footnote">Ожидаемое состояние Network для защиты: GET → https://dummyjson.com/users?limit=30 → HTTP 200 → JSON с массивом <code>users</code>.</div>
    </main>
  );
}
