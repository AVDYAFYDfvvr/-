import { useEffect, useMemo, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import FormField from '../components/FormField';
import LoadingState from '../components/LoadingState';
import { apiRequest } from '../services/api';

const initialForm = {
  fullName: '', profession: '', skills: '', hourlyRate: '', experienceYears: '0', city: '',
  contactEmail: '', contactPhone: '', status: 'available', description: '', image: '',
};

export default function SpecialistFormPage({ mode }) {
  const isEdit = mode === 'edit';
  const { id } = useParams();
  const navigate = useNavigate();
  const [form, setForm] = useState(initialForm);
  const [errors, setErrors] = useState({});
  const [serverError, setServerError] = useState('');
  const [loading, setLoading] = useState(isEdit);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (!isEdit) return;
    let active = true;
    apiRequest(`/me/specialists/${id}`)
      .then((data) => {
        if (active) setForm({ ...initialForm, ...data.specialist });
      })
      .catch((error) => {
        if (active) setServerError(error.message);
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => { active = false; };
  }, [id, isEdit]);

  const title = useMemo(() => (isEdit ? 'Редактировать профиль' : 'Новый профиль специалиста'), [isEdit]);

  function change(event) {
    setForm((current) => ({ ...current, [event.target.name]: event.target.value }));
    setErrors((current) => ({ ...current, [event.target.name]: '' }));
  }

  async function handleSubmit(event) {
    event.preventDefault();
    setErrors({}); setServerError(''); setSubmitting(true);
    try {
      const data = await apiRequest(isEdit ? `/specialists/${id}` : '/specialists', {
        method: isEdit ? 'PUT' : 'POST',
        body: { ...form, hourlyRate: Number(form.hourlyRate), experienceYears: Number(form.experienceYears) },
      });
      navigate(`/items/${data.specialist.id}`, { replace: true });
    } catch (error) {
      setServerError(error.message);
      setErrors(error.details?.errors || {});
    } finally {
      setSubmitting(false);
    }
  }

  if (loading) return <div className="container page-content"><LoadingState /></div>;

  return (
    <div className="container page-content narrow-content">
      <Link to="/dashboard" className="back-link">← В кабинет</Link>
      <div className="page-header compact">
        <div><div className="eyebrow">CRUD</div><h1>{title}</h1><p>Все обязательные поля валидируются сервером, а не только React-формой.</p></div>
      </div>

      {serverError && <div className="alert alert-error">{serverError}</div>}
      <form onSubmit={handleSubmit} className="profile-form">
        <div className="form-grid">
          <FormField label="ФИО" name="fullName" error={errors.fullName}>
            <input id="fullName" name="fullName" value={form.fullName} onChange={change} required />
          </FormField>
          <FormField label="Профессия" name="profession" error={errors.profession}>
            <input id="profession" name="profession" value={form.profession} onChange={change} required />
          </FormField>
          <FormField label="Навыки" name="skills" error={errors.skills} hint="Например: React, Node.js, SQL">
            <input id="skills" name="skills" value={form.skills} onChange={change} required />
          </FormField>
          <FormField label="Ставка, ₸/час" name="hourlyRate" error={errors.hourlyRate}>
            <input id="hourlyRate" type="number" min="1" max="1000000" name="hourlyRate" value={form.hourlyRate} onChange={change} required />
          </FormField>
          <FormField label="Опыт, лет" name="experienceYears" error={errors.experienceYears}>
            <input id="experienceYears" type="number" min="0" max="60" name="experienceYears" value={form.experienceYears} onChange={change} required />
          </FormField>
          <FormField label="Город" name="city" error={errors.city}>
            <input id="city" name="city" value={form.city} onChange={change} required />
          </FormField>
          <FormField label="Контактный email" name="contactEmail" error={errors.contactEmail}>
            <input id="contactEmail" type="email" name="contactEmail" value={form.contactEmail} onChange={change} required />
          </FormField>
          <FormField label="Телефон" name="contactPhone" error={errors.contactPhone}>
            <input id="contactPhone" type="tel" name="contactPhone" value={form.contactPhone} onChange={change} required />
          </FormField>
          <FormField label="Статус" name="status">
            <select id="status" name="status" value={form.status} onChange={change}>
              <option value="available">Свободен для заказов</option>
              <option value="busy">Занят</option>
            </select>
          </FormField>
          <FormField label="Изображение" name="image" error={errors.image} required={false} hint="Можно оставить пустым — будет создан аватар-заглушка.">
            <input id="image" type="url" name="image" value={form.image} onChange={change} placeholder="https://..." />
          </FormField>
        </div>
        <FormField label="Описание" name="description" error={errors.description} hint="20–500 символов.">
          <textarea id="description" name="description" value={form.description} onChange={change} required rows="6" />
        </FormField>
        <div className="form-actions">
          <Link to="/dashboard" className="button button-secondary">Отмена</Link>
          <button className="button button-primary" disabled={submitting}>{submitting ? 'Сохраняем…' : 'Сохранить профиль'}</button>
        </div>
      </form>
    </div>
  );
}
