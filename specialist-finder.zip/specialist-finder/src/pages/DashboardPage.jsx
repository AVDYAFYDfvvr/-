import { Link } from 'react-router-dom';
import { useEffect, useState } from 'react';
import EmptyState from '../components/EmptyState';
import ErrorState from '../components/ErrorState';
import LoadingState from '../components/LoadingState';
import PageHeader from '../components/PageHeader';
import SpecialistCard from '../components/SpecialistCard';
import { apiRequest } from '../services/api';

export default function DashboardPage() {
  const [specialists, setSpecialists] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  async function load() {
    setLoading(true); setError('');
    try {
      const data = await apiRequest('/me/specialists');
      setSpecialists(data.specialists);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { load(); }, []);

  async function handleDelete(id) {
    const confirmed = window.confirm('Удалить этот профиль? Действие нельзя отменить.');
    if (!confirmed) return;
    try {
      await apiRequest(`/specialists/${id}`, { method: 'DELETE' });
      setSpecialists((current) => current.filter((item) => item.id !== id));
    } catch (err) {
      setError(err.message);
    }
  }

  return (
    <div className="container page-content">
      <PageHeader
        eyebrow="Dashboard"
        title="Мои профили"
        text="Здесь отображаются только записи, которыми вы владеете. Сервер повторно проверяет ownerId при изменении и удалении."
        action={<Link to="/dashboard/new" className="button button-primary">+ Добавить профиль</Link>}
      />

      {loading && <LoadingState label="Загружаем ваши записи…" />}
      {error && !loading && <ErrorState message={error} onRetry={load} />}
      {!loading && !error && specialists.length === 0 && (
        <EmptyState
          title="У вас пока нет профилей"
          text="Создайте первую карточку специалиста, чтобы она появилась в вашем кабинете и публичном каталоге."
          action={<Link to="/dashboard/new" className="button button-primary">Создать профиль</Link>}
        />
      )}
      {!loading && !error && specialists.length > 0 && (
        <div className="card-grid">
          {specialists.map((specialist) => (
            <SpecialistCard
              specialist={specialist}
              key={specialist.id}
              actions={
                <>
                  <Link className="button button-ghost" to={`/dashboard/edit/${specialist.id}`}>Изменить</Link>
                  <button className="button button-ghost text-danger" onClick={() => handleDelete(specialist.id)}>Удалить</button>
                </>
              }
            />
          ))}
        </div>
      )}
    </div>
  );
}
