import { Link, useParams } from 'react-router-dom';
import { useEffect, useState } from 'react';
import Avatar from '../components/Avatar';
import ErrorState from '../components/ErrorState';
import LoadingState from '../components/LoadingState';
import { apiRequest } from '../services/api';

export default function SpecialistDetailsPage() {
  const { id } = useParams();
  const [specialist, setSpecialist] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  async function load() {
    setLoading(true); setError('');
    try {
      const data = await apiRequest(`/specialists/${id}`);
      setSpecialist(data.specialist);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { load(); }, [id]);

  if (loading) return <main className="container page-content"><LoadingState /></main>;
  if (error) return <main className="container page-content"><ErrorState message={error} onRetry={load} /></main>;

  const skills = specialist.skills.split(',').map((skill) => skill.trim()).filter(Boolean);

  return (
    <main className="container page-content">
      <Link className="back-link" to="/specialists">← Вернуться к каталогу</Link>
      <article className="profile-page">
        <div className="profile-main">
          <Avatar src={specialist.image} alt={specialist.fullName} size="hero" />
          <div>
            <span className={`status status-${specialist.status}`}>
              <span className="status-dot" />
              {specialist.status === 'available' ? 'Свободен для заказов' : 'Сейчас занят'}
            </span>
            <h1>{specialist.fullName}</h1>
            <p className="profile-profession">{specialist.profession}</p>
            <p className="profile-description">{specialist.description}</p>
          </div>
        </div>

        <div className="profile-grid">
          <section className="profile-section">
            <h2>Навыки</h2>
            <div className="skill-list skill-list-large">
              {skills.map((skill) => <span className="skill" key={skill}>{skill}</span>)}
            </div>
          </section>
          <section className="profile-section">
            <h2>Стоимость и опыт</h2>
            <div className="detail-list">
              <div><span>Ставка</span><strong>{new Intl.NumberFormat('ru-RU').format(specialist.hourlyRate)} ₸/час</strong></div>
              <div><span>Опыт</span><strong>{specialist.experienceYears} лет</strong></div>
              <div><span>Город</span><strong>{specialist.city}</strong></div>
            </div>
          </section>
          <section className="profile-section profile-contact">
            <h2>Контакты</h2>
            <a href={`mailto:${specialist.contactEmail}`}>{specialist.contactEmail}</a>
            <a href={`tel:${specialist.contactPhone}`}>{specialist.contactPhone}</a>
          </section>
        </div>
      </article>
    </main>
  );
}
