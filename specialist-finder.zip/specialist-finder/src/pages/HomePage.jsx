import { Link } from 'react-router-dom';

const features = [
  ['Поиск', 'Публичный каталог специалистов с поиском по имени, навыкам, профессии и городу.'],
  ['Профили', 'У каждого специалиста отдельная динамическая страница с контактами, ставкой и опытом.'],
  ['Личный кабинет', 'Авторизованный пользователь создаёт, редактирует и удаляет собственные профили.'],
  ['Внешний API', 'Раздел Explore загружает реальные данные DummyJSON через fetch и обрабатывает состояния UX.'],
];

export default function HomePage() {
  return (
    <main>
      <section className="hero">
        <div className="container hero-grid">
          <div>
            <div className="eyebrow">Сервис поиска специалистов</div>
            <h1>Найдите человека,<br /><span>который умеет делать.</span></h1>
            <p className="hero-text">ProFinder объединяет каталог специалистов и личный кабинет, где можно управлять собственными профилями.</p>
            <div className="hero-actions">
              <Link to="/specialists" className="button button-primary button-large">Открыть каталог</Link>
              <Link to="/explore" className="button button-secondary button-large">Посмотреть API Explore</Link>
            </div>
            <div className="hero-note">Данные CRUD сохраняются на Express-сервере в JSON-хранилище.</div>
          </div>
          <div className="hero-panel" aria-label="Ключевые возможности">
            <div className="hero-stat"><strong>CRUD</strong><span>создание, просмотр, изменение, удаление</span></div>
            <div className="hero-stat"><strong>Auth</strong><span>bcrypt + JWT + httpOnly cookie</span></div>
            <div className="hero-stat"><strong>API</strong><span>DummyJSON /users — реальные GET-данные</span></div>
            <div className="hero-stat"><strong>Router</strong><span>публичные и protected routes</span></div>
          </div>
        </div>
      </section>

      <section className="container section-block">
        <div className="section-title">
          <div><div className="eyebrow">О проекте</div><h2>Одна система вместо набора лабораторных</h2></div>
          <p>Каждый модуль связан с общей предметной областью: специалист создаёт профиль, профиль попадает в каталог, а владелец управляет им через кабинет.</p>
        </div>
        <div className="feature-grid">
          {features.map(([title, text]) => (
            <article key={title} className="feature-card">
              <span className="feature-number">0{features.findIndex(([item]) => item === title) + 1}</span>
              <h3>{title}</h3>
              <p>{text}</p>
            </article>
          ))}
        </div>
      </section>
    </main>
  );
}
