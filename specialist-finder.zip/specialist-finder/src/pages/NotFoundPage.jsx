import { Link } from 'react-router-dom';

export default function NotFoundPage() {
  return (
    <main className="container page-content not-found">
      <div className="eyebrow">404</div>
      <h1>Страница не найдена</h1>
      <p>Маршрут не существует. Проверьте адрес или вернитесь в каталог.</p>
      <Link className="button button-primary" to="/specialists">Перейти к специалистам</Link>
    </main>
  );
}
