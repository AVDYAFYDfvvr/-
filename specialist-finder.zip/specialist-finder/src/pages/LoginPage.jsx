import { useState } from 'react';
import { Link, Navigate, useLocation, useNavigate } from 'react-router-dom';
import FormField from '../components/FormField';
import { useAuth } from '../context/AuthContext';

export default function LoginPage() {
  const { user, login } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [form, setForm] = useState({ email: '', password: '' });
  const [serverError, setServerError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  if (user) return <Navigate to="/dashboard" replace />;

  function change(event) {
    setForm((current) => ({ ...current, [event.target.name]: event.target.value }));
  }

  async function handleSubmit(event) {
    event.preventDefault();
    setServerError(''); setSubmitting(true);
    try {
      await login(form);
      const from = location.state?.from;
      const target = from ? `${from.pathname}${from.search || ''}${from.hash || ''}` : '/dashboard';
      navigate(target, { replace: true });
    } catch (error) {
      setServerError(error.message);
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <main className="auth-page container">
      <section className="auth-card">
        <div className="eyebrow">Вход</div>
        <h1>С возвращением</h1>
        <p className="muted">Сессия хранится в httpOnly cookie и восстанавливается после обновления страницы.</p>
        {serverError && <div className="alert alert-error">{serverError}</div>}
        <form onSubmit={handleSubmit} className="form-stack">
          <FormField label="Email" name="email">
            <input id="email" type="email" name="email" value={form.email} onChange={change} required autoComplete="email" />
          </FormField>
          <FormField label="Пароль" name="password">
            <input id="password" type="password" name="password" value={form.password} onChange={change} required autoComplete="current-password" />
          </FormField>
          <button className="button button-primary button-full" disabled={submitting}>{submitting ? 'Проверяем…' : 'Войти'}</button>
        </form>
        <p className="auth-footer">Нет аккаунта? <Link to="/register">Зарегистрироваться</Link></p>
      </section>
    </main>
  );
}
