import { useState } from 'react';
import { Link, Navigate, useLocation, useNavigate } from 'react-router-dom';
import FormField from '../components/FormField';
import { useAuth } from '../context/AuthContext';

export default function RegisterPage() {
  const { user, register } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [form, setForm] = useState({ name: '', email: '', password: '' });
  const [errors, setErrors] = useState({});
  const [serverError, setServerError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  if (user) return <Navigate to="/dashboard" replace />;

  function change(event) {
    setForm((current) => ({ ...current, [event.target.name]: event.target.value }));
    setErrors((current) => ({ ...current, [event.target.name]: '' }));
  }

  async function handleSubmit(event) {
    event.preventDefault();
    setErrors({}); setServerError(''); setSubmitting(true);
    try {
      await register(form);
      const target = location.state?.from?.pathname || '/dashboard';
      navigate(target, { replace: true });
    } catch (error) {
      setServerError(error.message);
      setErrors(error.details?.errors || {});
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <main className="auth-page container">
      <section className="auth-card">
        <div className="eyebrow">Новый аккаунт</div>
        <h1>Создать профиль доступа</h1>
        <p className="muted">После регистрации вы сможете добавлять и управлять собственными профилями специалистов.</p>
        {serverError && <div className="alert alert-error">{serverError}</div>}
        <form onSubmit={handleSubmit} className="form-stack">
          <FormField label="Имя" name="name" error={errors.name} hint="Отображается в личном кабинете.">
            <input id="name" name="name" value={form.name} onChange={change} required autoComplete="name" />
          </FormField>
          <FormField label="Email" name="email" error={errors.email}>
            <input id="email" type="email" name="email" value={form.email} onChange={change} required autoComplete="email" />
          </FormField>
          <FormField label="Пароль" name="password" error={errors.password} hint="Минимум 6 символов.">
            <input id="password" type="password" name="password" value={form.password} onChange={change} required minLength={6} autoComplete="new-password" />
          </FormField>
          <button className="button button-primary button-full" disabled={submitting}>{submitting ? 'Создаём аккаунт…' : 'Зарегистрироваться'}</button>
        </form>
        <p className="auth-footer">Уже есть аккаунт? <Link to="/login">Войти</Link></p>
      </section>
    </main>
  );
}
