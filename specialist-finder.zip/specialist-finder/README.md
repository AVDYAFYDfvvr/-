# ProFinder — сервис поиска специалистов

Итоговая практическая работа по теме **«React: от компонентов до полноценного сайта»**.

## Предметная область

Сервис поиска специалистов. Основная сущность CRUD — профиль специалиста.

Поля профиля:
- ФИО
- профессия
- навыки
- стоимость в ₸/час (числовое поле)
- опыт в годах (числовое поле)
- город
- контактный email
- телефон
- статус: `available` / `busy`
- описание
- изображение

## Стек

Frontend: React, JSX, React Router DOM, Context API, hooks (`useState`, `useEffect`, `useContext`), Vite, HTML/CSS.

Backend: Node.js, Express, JSON-файлы, bcryptjs, JWT, httpOnly cookie, CORS.

External API: DummyJSON `GET https://dummyjson.com/users?limit=30`.

## Структура

```text
specialist-finder/
├─ data/
│  ├─ users.json
│  └─ specialists.json
├─ server/
│  └─ index.js
├─ src/
│  ├─ components/
│  ├─ context/
│  ├─ pages/
│  ├─ services/
│  ├─ styles/
│  ├─ App.jsx
│  └─ main.jsx
├─ .env.example
├─ index.html
├─ package.json
└─ README.md
```

## Запуск в Visual Studio Code

### 1. Открыть проект

Откройте папку проекта в VS Code.

### 2. Открыть встроенный терминал

```powershell
npm install
```

### 3. Создать `.env`

Скопируйте `.env.example` в `.env`:

PowerShell:

```powershell
Copy-Item .env.example .env
```

После этого при необходимости измените `JWT_SECRET`.

### 4. Запустить frontend + backend

```powershell
npm run dev
```

Frontend: `http://localhost:5173`

Backend API: `http://localhost:4000`

### Альтернативный запуск в двух терминалах

Терминал 1:

```powershell
npm run dev:server
```

Терминал 2:

```powershell
npm run dev:client
```

## Маршруты

| Маршрут | Доступ | Назначение |
|---|---|---|
| `/` | public | Главная |
| `/specialists` | public | Каталог + поиск + фильтр |
| `/items/:id` | public | Динамический профиль специалиста (`useParams`) |
| `/register` | public | Регистрация |
| `/login` | public | Вход |
| `/dashboard` | protected | Личные профили пользователя |
| `/dashboard/new` | protected | CREATE |
| `/dashboard/edit/:id` | protected | UPDATE |
| `/explore` | public | GET к DummyJSON + поиск |
| `/404` | public | Страница 404 |

## Где реализованы обязательные требования

### React и компоненты

- функциональные компоненты и JSX;
- props в `SpecialistCard`, `Avatar`, `FormField`, `PageHeader`;
- `map()` и стабильные `key`;
- `useState` для форм, фильтров, состояний загрузки;
- `useEffect` для загрузки и очистки эффектов;
- `useContext` через `AuthContext`.

### React Router

Используются `BrowserRouter`, `Routes`, `Route`, `Link`, `NavLink`, `Outlet`, `useParams`, `Navigate`.

`ProtectedRoute` не просто скрывает кнопку: он перенаправляет гостя на `/login` и сохраняет исходный маршрут в `location.state`.

### Авторизация

- регистрация по имени, email и паролю;
- дубликаты email отклоняются сервером;
- пароль хранится только как `bcrypt`-хеш;
- JWT хранится в `httpOnly` cookie;
- `/api/auth/me` восстанавливает сессию после обновления страницы;
- выход очищает cookie;
- серверные POST/PUT/DELETE требуют валидную сессию.

### Владелец записи

Каждый пользовательский профиль получает `ownerId`.

Для PUT/DELETE сервер сравнивает `ownerId` с текущим пользователем. Поэтому попытка изменить или удалить чужую запись напрямую HTTP-запросом получает `403`.

### CRUD

- `POST /api/specialists` — CREATE
- `GET /api/specialists` и `GET /api/specialists/:id` — READ
- `PUT /api/specialists/:id` — UPDATE
- `DELETE /api/specialists/:id` — DELETE

Данные находятся в `data/specialists.json`, поэтому не исчезают после перезагрузки браузера или перезапуска приложения.

### Внешний API

Страница `/explore` делает реальный `fetch()` к DummyJSON:

```text
GET https://dummyjson.com/users?limit=30
```

Результат сохраняется в React state. На странице есть:

- минимум 8 карточек;
- изображение;
- имя;
- должность/компания;
- возраст;
- город;
- email;
- телефон;
- loading;
- error;
- empty;
- Retry;
- интерактивный поиск по уже загруженным данным;
- `AbortController` при очистке `useEffect`.

## Сценарий демонстрации преподавателю

1. Открыть `/register`, создать пользователя.
2. После регистрации показать `/dashboard`.
3. Создать новый профиль.
4. Открыть `/items/:id` и убедиться, что запись появилась.
5. Вернуться в `/dashboard`, изменить профиль.
6. Удалить профиль с подтверждением.
7. Обновить страницу и показать, что данные хранятся на сервере.
8. Выйти.
9. Открыть `/dashboard` вручную — должен быть редирект на `/login`.
10. Войти повторно — открывается dashboard.
11. Зарегистрировать второго пользователя.
12. Вызвать PUT/DELETE чужого `id` из DevTools или Postman — сервер должен вернуть `403`.
13. Открыть `/explore` и показать Network: URL DummyJSON, статус 200, JSON ответ.
14. Выполнить поиск на `/explore` без полной перезагрузки.
15. Для проверки ошибки сети отключить интернет и нажать «Повторить».
16. Открыть несуществующий URL — `/404`.

## Проверка production-сборки

```powershell
npm run build
```

## Важное для сдачи

Не добавляйте в ZIP папку `node_modules` и файл `.env` с реальным секретом. В архиве достаточно `.env.example`.

## Внешний API

Документация DummyJSON Users: https://dummyjson.com/docs/users
