import express from 'express';
import cors from 'cors';
import cookieParser from 'cookie-parser';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import crypto from 'node:crypto';
import 'dotenv/config';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const DATA_DIR = path.join(__dirname, '..', 'data');
const USERS_FILE = path.join(DATA_DIR, 'users.json');
const SPECIALISTS_FILE = path.join(DATA_DIR, 'specialists.json');

const app = express();
const PORT = Number(process.env.PORT || 4000);
const CLIENT_ORIGIN = process.env.CLIENT_ORIGIN || 'http://localhost:5173';
const JWT_SECRET = process.env.JWT_SECRET || 'dev-secret-change-me';
const isProduction = process.env.NODE_ENV === 'production';
const COOKIE_NAME = 'pro_finder_token';

app.use(cors({ origin: CLIENT_ORIGIN, credentials: true }));
app.use(express.json({ limit: '100kb' }));
app.use(cookieParser());

async function ensureDataFiles() {
  await fs.mkdir(DATA_DIR, { recursive: true });
  for (const [file, fallback] of [[USERS_FILE, []], [SPECIALISTS_FILE, []]]) {
    try {
      await fs.access(file);
    } catch {
      await fs.writeFile(file, JSON.stringify(fallback, null, 2));
    }
  }
}

async function readJson(file) {
  const raw = await fs.readFile(file, 'utf8');
  return JSON.parse(raw);
}

async function writeJson(file, data) {
  const tempFile = `${file}.tmp`;
  await fs.writeFile(tempFile, JSON.stringify(data, null, 2));
  await fs.rename(tempFile, file);
}

function signToken(user) {
  return jwt.sign({ sub: user.id, role: user.role }, JWT_SECRET, { expiresIn: '7d' });
}

function publicUser(user) {
  return { id: user.id, name: user.name, email: user.email, role: user.role };
}

function setAuthCookie(res, user) {
  res.cookie(COOKIE_NAME, signToken(user), {
    httpOnly: true,
    secure: isProduction,
    sameSite: 'lax',
    maxAge: 7 * 24 * 60 * 60 * 1000,
  });
}

function clearAuthCookie(res) {
  res.clearCookie(COOKIE_NAME, {
    httpOnly: true,
    secure: isProduction,
    sameSite: 'lax',
  });
}

async function authRequired(req, res, next) {
  try {
    const token = req.cookies[COOKIE_NAME];
    if (!token) return res.status(401).json({ message: 'Необходимо войти в аккаунт.' });

    const payload = jwt.verify(token, JWT_SECRET);
    const users = await readJson(USERS_FILE);
    const user = users.find((item) => item.id === payload.sub);
    if (!user) return res.status(401).json({ message: 'Сессия недействительна.' });

    req.user = user;
    next();
  } catch {
    return res.status(401).json({ message: 'Сессия истекла. Войдите снова.' });
  }
}

function validateRegistration(body) {
  const name = String(body.name ?? '').trim();
  const email = String(body.email ?? '').trim().toLowerCase();
  const password = String(body.password ?? '');
  const errors = {};

  if (name.length < 2 || name.length > 60) errors.name = 'Имя должно содержать от 2 до 60 символов.';
  if (!/^\S+@\S+\.\S+$/.test(email)) errors.email = 'Введите корректный email.';
  if (password.length < 6) errors.password = 'Пароль должен содержать минимум 6 символов.';

  return { errors, value: { name, email, password } };
}

function validateSpecialist(body) {
  const value = {
    fullName: String(body.fullName ?? '').trim(),
    profession: String(body.profession ?? '').trim(),
    skills: String(body.skills ?? '').trim(),
    hourlyRate: Number(body.hourlyRate),
    experienceYears: Number(body.experienceYears),
    city: String(body.city ?? '').trim(),
    contactEmail: String(body.contactEmail ?? '').trim().toLowerCase(),
    contactPhone: String(body.contactPhone ?? '').trim(),
    status: body.status === 'busy' ? 'busy' : 'available',
    description: String(body.description ?? '').trim(),
    image: String(body.image ?? '').trim(),
  };

  const errors = {};
  if (value.fullName.length < 2 || value.fullName.length > 80) errors.fullName = 'ФИО: от 2 до 80 символов.';
  if (value.profession.length < 2 || value.profession.length > 100) errors.profession = 'Профессия: от 2 до 100 символов.';
  if (value.skills.length < 2 || value.skills.length > 300) errors.skills = 'Укажите навыки через запятую.';
  if (!Number.isFinite(value.hourlyRate) || value.hourlyRate < 1 || value.hourlyRate > 1000000) errors.hourlyRate = 'Ставка: от 1 до 1 000 000 ₸/час.';
  if (!Number.isInteger(value.experienceYears) || value.experienceYears < 0 || value.experienceYears > 60) errors.experienceYears = 'Опыт: целое число от 0 до 60 лет.';
  if (value.city.length < 2 || value.city.length > 80) errors.city = 'Укажите город.';
  if (!/^\S+@\S+\.\S+$/.test(value.contactEmail)) errors.contactEmail = 'Введите корректный рабочий email.';
  if (value.contactPhone.length < 7 || value.contactPhone.length > 30) errors.contactPhone = 'Введите корректный телефон.';
  if (value.description.length < 20 || value.description.length > 500) errors.description = 'Описание: от 20 до 500 символов.';
  if (value.image && !/^https?:\/\//i.test(value.image)) errors.image = 'Ссылка на изображение должна начинаться с http:// или https://.';

  return { errors, value };
}

app.get('/api/health', (_req, res) => res.json({ status: 'ok', service: 'ProFinder API' }));

app.post('/api/auth/register', async (req, res) => {
  const { errors, value } = validateRegistration(req.body);
  if (Object.keys(errors).length) return res.status(400).json({ message: 'Проверьте форму.', errors });

  const users = await readJson(USERS_FILE);
  if (users.some((user) => user.email === value.email)) {
    return res.status(409).json({ message: 'Пользователь с таким email уже существует.' });
  }

  const passwordHash = await bcrypt.hash(value.password, 12);
  const user = {
    id: crypto.randomUUID(),
    name: value.name,
    email: value.email,
    passwordHash,
    role: 'user',
    createdAt: new Date().toISOString(),
  };

  users.push(user);
  await writeJson(USERS_FILE, users);
  setAuthCookie(res, user);
  res.status(201).json({ user: publicUser(user) });
});

app.post('/api/auth/login', async (req, res) => {
  const email = String(req.body.email ?? '').trim().toLowerCase();
  const password = String(req.body.password ?? '');
  const users = await readJson(USERS_FILE);
  const user = users.find((item) => item.email === email);
  if (!user || !(await bcrypt.compare(password, user.passwordHash))) {
    return res.status(401).json({ message: 'Неверный email или пароль.' });
  }

  setAuthCookie(res, user);
  res.json({ user: publicUser(user) });
});

app.post('/api/auth/logout', (_req, res) => {
  clearAuthCookie(res);
  res.status(204).send();
});

app.get('/api/auth/me', authRequired, (req, res) => {
  res.json({ user: publicUser(req.user) });
});

app.get('/api/specialists', async (_req, res) => {
  const specialists = await readJson(SPECIALISTS_FILE);
  res.json({ specialists });
});

app.get('/api/specialists/:id', async (req, res) => {
  const specialists = await readJson(SPECIALISTS_FILE);
  const specialist = specialists.find((item) => item.id === req.params.id);
  if (!specialist) return res.status(404).json({ message: 'Специалист не найден.' });
  res.json({ specialist });
});

app.get('/api/me/specialists', authRequired, async (req, res) => {
  const specialists = await readJson(SPECIALISTS_FILE);
  res.json({ specialists: specialists.filter((item) => item.ownerId === req.user.id) });
});

app.get('/api/me/specialists/:id', authRequired, async (req, res) => {
  const specialists = await readJson(SPECIALISTS_FILE);
  const specialist = specialists.find((item) => item.id === req.params.id);
  if (!specialist) return res.status(404).json({ message: 'Профиль не найден.' });
  if (specialist.ownerId !== req.user.id) return res.status(403).json({ message: 'Нет доступа к чужому профилю.' });
  res.json({ specialist });
});

app.post('/api/specialists', authRequired, async (req, res) => {
  const { errors, value } = validateSpecialist(req.body);
  if (Object.keys(errors).length) return res.status(400).json({ message: 'Проверьте поля профиля.', errors });

  const specialists = await readJson(SPECIALISTS_FILE);
  const now = new Date().toISOString();
  const specialist = {
    id: crypto.randomUUID(),
    ownerId: req.user.id,
    ...value,
    createdAt: now,
    updatedAt: now,
  };
  specialists.unshift(specialist);
  await writeJson(SPECIALISTS_FILE, specialists);
  res.status(201).json({ specialist });
});

app.put('/api/specialists/:id', authRequired, async (req, res) => {
  const specialists = await readJson(SPECIALISTS_FILE);
  const index = specialists.findIndex((item) => item.id === req.params.id);
  if (index === -1) return res.status(404).json({ message: 'Специалист не найден.' });

  const specialist = specialists[index];
  if (specialist.ownerId !== req.user.id) {
    return res.status(403).json({ message: 'Нельзя изменять чужой профиль.' });
  }

  const { errors, value } = validateSpecialist(req.body);
  if (Object.keys(errors).length) return res.status(400).json({ message: 'Проверьте поля профиля.', errors });

  const updated = { ...specialist, ...value, updatedAt: new Date().toISOString() };
  specialists[index] = updated;
  await writeJson(SPECIALISTS_FILE, specialists);
  res.json({ specialist: updated });
});

app.delete('/api/specialists/:id', authRequired, async (req, res) => {
  const specialists = await readJson(SPECIALISTS_FILE);
  const index = specialists.findIndex((item) => item.id === req.params.id);
  if (index === -1) return res.status(404).json({ message: 'Специалист не найден.' });

  if (specialists[index].ownerId !== req.user.id) {
    return res.status(403).json({ message: 'Нельзя удалять чужой профиль.' });
  }

  const [removed] = specialists.splice(index, 1);
  await writeJson(SPECIALISTS_FILE, specialists);
  res.json({ specialist: removed });
});

app.use((_req, res) => res.status(404).json({ message: 'API маршрут не найден.' }));

ensureDataFiles().then(() => {
  app.listen(PORT, () => {
    console.log(`ProFinder API: http://localhost:${PORT}`);
  });
}).catch((error) => {
  console.error('Не удалось подготовить данные:', error);
  process.exit(1);
});
